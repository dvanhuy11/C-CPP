#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
	char info;// phan du lieu
	struct node* next;// phan dia chi: next
}; 
node* createnodeds(char x)
{
	node* t;
	t=(node*)malloc(sizeof(struct node));// tra ve dia chi cua vung nho duoc cap nhat
	t->info=x;
	t->next=NULL;
	return t;
}
node* insertLast(node* &p,char x)
{
	node*t=createnodeds(x);
	if(p==NULL)
	{
		p=t;
		return p;	
	}	
	//Tim phan tu o cuoi mang 
	node* i=p;
	while(i->next!=NULL)
	{
		i=i->next;
	}
	//gan phan tu moi vao cuoi mang
	i->next=t;
}

void showList(node* p)
{
	printf("\nOutput: ");
	node* i=p;
	while(i!=NULL)
	{
		printf("%c",i->info);
		i=i->next;
	}
} 

