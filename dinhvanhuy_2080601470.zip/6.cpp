#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue1.h"
int main()
{
	queue q;
	int n;

	printf("\nNhap so luong benh nhan : ");
	scanf("%d", &n);
	InPut(q,n);
	OutPut(q);
	
	xuatBNTT(q);

	xuatBNDaKham(q,n);

	printf("\nSo luong benh nhan chua kham : %d", soLuong(q));
	
	printf("\n\nBenh nhan con trong hang doi cho kham");
	OutPut(q);
	GiaiPhong(q);
	return 0;
}
