#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
void Convert(int n,stack* &p)
{
	int sodu=0;
	while(n!=0)
	{
		sodu=n%2;
		push(p,sodu);
		n=n/2;
	}
}
void output(stack* p)
{
	printf("\nKet qua la:");
	while(p!=NULL)
	{
		stack* x=pop(p);
		printf("%d",x->info);
		free(x);
	}
}
int main()
{
	stack* p=NULL;
	int n;
	printf("Nhap n:");
	scanf("%d",&n);
	Convert(n,p);
	output(p);
	return 0;
}
