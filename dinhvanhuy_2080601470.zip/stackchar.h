#include<stdio.h>
#include<stdlib.h>
typedef struct stack
{
	char info;
	struct stack* next;
};
bool isEmpty(stack* p)
{
	if(p==NULL)
	{
		return true;
	}
	return false;
}
stack* createnode(char x)
{
	stack* t;
	t=(stack*)malloc(sizeof(struct stack));
	t->info=x;
	t->next=NULL;
	return t;
}
void push(stack* &p, char x)
{
 	stack* t=createnode(x);		  
 	t->next=p;
 	p=t;
}
stack* pop(stack* &p)
{
	if(p==NULL)
	{
		return NULL;
	}
	stack* t=p;
	p=p->next;
	return t;
}
void showList(stack* p)
{
	printf("\nStack: ");
	stack* i=p;
	while(i!=NULL)
	{
		printf("%c",i->info);
		i=i->next;
	}
} 
