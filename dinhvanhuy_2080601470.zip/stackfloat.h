#include<stdio.h>
#include<stdlib.h>
typedef struct stackf
{
	float info;
	struct stackf* next;
};
bool isEmpty(stackf *p)
{
	if(p==NULL)
	{
		return true;
	}
	return false;
}
stackf* createnode(float x)
{
	stackf* t;
	t=(stackf*)malloc(sizeof(struct stackf));
	t->info=x;
	t->next=NULL;
	return t;
}
void push(stackf* &p, float x)
{
 	stackf* t=createnode(x);
	t->info=x;			  
 	t->next=p;
 	p=t;
}
stackf* pop(stackf* &p)
{
	if(p==NULL)
	{
		return NULL;
	}
	stackf* t=p;
	p=p->next;
	return t;
}
void showList(stackf* p)
{
	printf("\nHien thi danh sach");
	stackf *i=p;
	while(i!=NULL)
	{
		printf("%5d",i->info);
		i=i->next;
	}
} 
