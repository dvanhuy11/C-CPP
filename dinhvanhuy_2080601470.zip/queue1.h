#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct benhnhan{
	int STT;
	char HoTen[40];
	int tuoi;
};
typedef struct node {
	benhnhan info;
	node *pNext;
};
typedef struct queue {
	node *pHead;
	node *pTail;
};
void addBN(benhnhan &b)
{
	printf("\nNhap Ho Ten:");
	scanf("%s",&b.HoTen);
	printf("\nNhap Tuoi:");
	scanf("%d",&b.tuoi);
}
void showBN(benhnhan b)
{
	printf("Ho va ten benh nhan : %s", b.HoTen);
	printf("\nTuoi benh nhan : %d", b.tuoi);
}
void Init(queue &q)
{
	q.pHead = q.pTail = NULL;
}
node* GetNode(benhnhan x)
{
	node *p = new node;
	if (p == NULL)
	{
		return NULL;
	}
	p->info = x;
	p->pNext = NULL;
	return p;
}
void AddTail(queue &q, node *p)
{
	if (q.pHead == NULL)
	{
		q.pHead = q.pTail = p;
	}
	else 
	{
		q.pTail -> pNext = p;
		q.pTail = p;
	}
}
void XoaDau(queue &q)
{
	node *p = q.pHead;
	q.pHead = q.pHead->pNext;
	delete p;
}
void InPut(queue &q, int &n)
{
	node *p = new node;
	Init(q);
	for (int i = 1; i <= n; i++) 
	{
		benhnhan x;
		addBN(x);
		node *p = GetNode(x);
		AddTail(q,p);
	}
}
void OutPut(queue q)
{
	int stt = 0;
	for (node *p = q.pHead; p!=NULL;p=p->pNext)
	{
		stt++;
		printf("\nSTT: %d\n", stt);
		showBN(p->info);
	}
}
void xuatBNTT(queue &q)
{
	for (node*k=q.pHead; k != NULL; k=k->pNext)
	{
		printf("\n\nBenh nhan kham tiep theo\n");
		showBN(k->info);
		break;
	}
}
void xuatBNDaKham(queue &q, int &n)
{
	int k, i = 0;
	printf("\n\nNhap so luong nguoi da kham : ");
	do 
	{
		scanf("%d", &k);
	} while (k < 0 || k > n);
	printf("Benh nhan da kham\n");
	if (k == 0)
	{
		printf("Khong co benh nhan nao da kham\n");
		return;	
	}	
	for (node*z=q.pHead; z!=NULL;z=z->pNext)
	{
		i++;
		if (i <= k)
		{
			showBN(z->info);
			printf("\n");
			XoaDau(q);
		}
	}
}

int soLuong(queue &q)
{
	int count = 0;
	for (node*k=q.pHead; k != NULL; k = k->pNext)
	{
		count++;
	}
	return count;
}
void GiaiPhong(queue &q)
{
	node *p;
	while (q.pHead != NULL)
	{
		p = q.pHead;
		q.pHead = q.pHead -> pNext;
		delete p;
	}
}


